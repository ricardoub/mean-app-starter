## Template usado para a aplicação Meat - Angular
